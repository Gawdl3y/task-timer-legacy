$(document).ready(function() {
	localisePage();
});